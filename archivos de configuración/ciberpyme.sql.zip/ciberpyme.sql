-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-06-2019 a las 19:57:43
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ciberpyme`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activos`
--

CREATE TABLE `activos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identificador` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `activos`
--

INSERT INTO `activos` (`id`, `identificador`, `descripcion`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Arq1', 'Trabajador arquitecto 1: Alexander Pérez', 1, NULL, NULL),
(2, 'Arq2', 'Trabajador arquitecto 2: Juana García', 1, NULL, NULL),
(3, 'PC1', 'Ordenador del arquitecto 1', 1, NULL, NULL),
(4, 'PC2', 'Ordenador del arquitecto 2', 1, NULL, NULL),
(5, 'Tel', 'Teléfono móvil de arquitectos', 1, NULL, NULL),
(6, 'Hab1', 'Despacho o habitación donde se trabaja', 1, NULL, NULL),
(7, 'Imp', 'Impresora A4 Inyección de tinta a color', 1, NULL, NULL),
(8, 'Inet', 'Conexión a internet por Wifi conrouter Movistar', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amenazas`
--

CREATE TABLE `amenazas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_amenaza` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `amenazas`
--

INSERT INTO `amenazas` (`id`, `id_amenaza`, `descripcion`, `activo_id`, `created_at`, `updated_at`) VALUES
(1, 'P1', 'Enfermedad-Indisposición', 1, NULL, NULL),
(2, 'P2', 'extorsión', 1, NULL, NULL),
(3, 'P3', 'Paternidad', 1, NULL, NULL),
(4, 'P4', 'Ingeniería Social (Robo de claves)', 1, NULL, NULL),
(5, 'P5', 'Enfermedad-Indisposición', 2, NULL, NULL),
(6, 'P6', 'Extorsión', 2, NULL, NULL),
(7, 'P7', 'Maternidad', 2, NULL, NULL),
(8, 'P8', 'Ingeniería Social (Robo de claves) ', 2, NULL, NULL),
(9, 'H1', 'Desastre Natural: Fuego, Agua, Eléctrico.', 3, NULL, NULL),
(10, 'H2', 'Difusión de Software dañino, virus, troyanos, etc.', 3, NULL, NULL),
(11, 'H3', 'Robo', 3, NULL, NULL),
(12, 'H4', 'Caída del sistema por fallo eléctrico o de software.', 3, NULL, NULL),
(13, 'H5', 'Rotura de elemento físico (Fuente de alimentación, memoriarAM, Placa base, etc.)', 3, NULL, NULL),
(14, 'H6', 'Pérdida de Información', 3, NULL, NULL),
(15, 'H7', 'Desastre Natural: Fuego, Agua, Eléctrico.', 4, NULL, NULL),
(16, 'H8', 'Difusión de Software dañino, virus, troyanos, etc.', 4, NULL, NULL),
(17, 'H9', 'Robo', 4, NULL, NULL),
(18, 'H10', 'Caída del sistema por fallo eléctrico o de software.', 4, NULL, NULL),
(19, 'H11', 'Rotura de elemento físico (Fuente de alimentación, memoriarAM, Placa base, etc.)', 4, NULL, NULL),
(20, 'H12', 'Robo, avería o pérdida física del teléfono', 5, NULL, NULL),
(21, 'H13', 'Exfiltración de información', 5, NULL, NULL),
(22, 'H14', 'Fallo en las comunicaciones', 5, NULL, NULL),
(23, 'H15', 'Rotura o avería', 7, NULL, NULL),
(24, 'H16', 'Falta de consumibles', 7, NULL, NULL),
(25, 'F1', 'Daño Natural (fuego, agua, obras, etc.)', 6, NULL, NULL),
(26, 'F2', 'Acceso no autorizado', 6, NULL, NULL),
(27, 'C1', 'Caída del servicio, fallo en comunicaciones', 8, NULL, NULL),
(28, 'C2', 'Interceptación de la comunicación (Robo de Wifi, ataque Man in the Middle, etc.)', 8, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `decisions`
--

CREATE TABLE `decisions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `riesgo_id` bigint(20) UNSIGNED NOT NULL,
  `estrategia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `decisions`
--

INSERT INTO `decisions` (`id`, `riesgo_id`, `estrategia`, `descripcion`, `created_at`, `updated_at`) VALUES
(1, 1, 'A', 'Vamos a asumir el riesgo de que se pueda producir una baja por enfermedad', NULL, NULL),
(2, 2, 'A', 'No Especificado', NULL, NULL),
(3, 3, 'A', 'No Especificado', NULL, NULL),
(4, 4, 'No Especificado', 'Hemos decidido implantar una política de contraseñas robusta y una separación de privilegios. Los trabajadores arquitectos a partir de ahora iniciarán sesión con un usuario normal, y si tienen que instalar o ejecutar un programa con privilegios de administrador, se introducirá la clave de Administrador en ese caso concreto', NULL, NULL),
(5, 5, 'A', 'Vamos a asumirlo y no tratar de buscar posibles soluciones, porque un plan de salud sería mu caro.', NULL, NULL),
(6, 6, 'No Especificado', 'No Especificado', NULL, NULL),
(7, 7, 'No Especificado', 'No Especificado', NULL, NULL),
(8, 8, 'Implantar', 'Hemos decidido implantar una política de contraseñas robusta y una separación de privilegios. Los trabajadores arquitectos a partir de ahora iniciarán sesión con un usuario normal, y si tienen que instalar o ejecutar un programa con privilegios de administrador, se introducirá la clave de Administrador en ese caso concreto', NULL, NULL),
(9, 9, 'No Especificado', 'No Especificado', NULL, NULL),
(10, 10, 'I', 'Implantar una medida que dará solución al problema de ambos ordenadores, crearemos una tarea en Windows (Gestor de tareas) para que automáticamente cada lunes actualice de manera forzosa el antivirus. También actualizaremos los sistemas a una solución completa de gestión de amenazas, así en lugar de solo antivirus contrataremos una solución “Total” que incluya otros servicios, como firewall, protección contra Ransomware, control parental, gestor de contraseñas, etc. ', NULL, NULL),
(11, 11, 'No Especificado', 'No Especificado', NULL, NULL),
(12, 12, 'I', 'hemos decidido comprar un pequeño SAI (Sistema de Alimentación Ininterrumpida) para que, en el caso de corte de luz, podamos guardar los datos y no perder la información con la que estemos trabajando. Extender este sistema al resto de ordenadores, es demasiado costoso, así que hemos decidido cubrir solo lo esencial en este aspecto. El resto de vicisitudes las asumimos.', NULL, NULL),
(13, 13, 'No Especificado', 'No Especificado', NULL, NULL),
(14, 14, 'T', 'Vamos a contratar un sistema de copias de seguridad en la nube.', NULL, NULL),
(15, 15, 'No Especificado', 'No Especificado', NULL, NULL),
(16, 16, 'I', 'Implantar una medida que dará solución al problema de ambos ordenadores, crearemos una tarea en Windows (Gestor de tareas) para que automáticamente cada lunes actualice de manera forzosa el antivirus. También actualizaremos los sistemas a una solución completa de gestión de amenazas, así en lugar de solo antivirus contrataremos una solución “Total” que incluya otros servicios, como firewall, protección contra Ransomware, control parental, gestor de contraseñas, etc. ', NULL, NULL),
(17, 17, 'No Especificado', 'No Especificado', NULL, NULL),
(18, 18, 'No Especificado', 'No Especificado', NULL, NULL),
(19, 19, 'No Especificado', 'No Especificado', NULL, NULL),
(20, 20, 'T', 'Tendremos un dispositivo como auxiliar y todos los datos del terminal (contactos, imágenes, etc.) sincronizados en la nube con los servicios de Google (Gmail, Google Photos, etc.). En caso de pérdida, todos esos datos se sincronizarán con el nuevo terminal de manera inmediata', NULL, NULL),
(21, 21, 'I', 'Decidimos implantar un sistema de bloqueo automático propio del teléfono, protegido por un patrón.', NULL, NULL),
(22, 22, 'No Especificado', 'No Especificado', NULL, NULL),
(23, 23, 'E', 'Toda la documentación se llevará de manera digital. si hay que imprimir algo se hará en un servicio externo puntual', NULL, NULL),
(24, 24, 'T', 'Contratar un servicio de impresión bajo demanda (renting)', NULL, NULL),
(25, 25, 'I', 'Para paliar este riesgo vamos a implementar un sistema de copias de seguridad en la nube y vamos a comprar un extintor pequeño de polvo polivalente para apagar pequeños conatos de incendio', NULL, NULL),
(26, 26, 'E', 'Pondremos una llave electrónica biométrica o por RFID para el acceso al despacho', NULL, NULL),
(27, 27, 'T', 'Se usará el servicio de internet en el móvil contratado con otra compañia', NULL, NULL),
(28, 28, 'I', 'Se comprará un firewall dedicado para proteger el acceso y las comunicaciones.', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_05_31_071956_create_activos_table', 1),
(4, '2019_06_06_054304_create_amenazas_table', 1),
(5, '2019_06_06_061230_create_salvavulneras_table', 1),
(6, '2019_06_06_070345_create_riesgos_table', 1),
(7, '2019_06_14_125633_create_decisions_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `riesgos`
--

CREATE TABLE `riesgos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `amenaza_id` bigint(20) UNSIGNED NOT NULL,
  `probabilidad` int(11) NOT NULL,
  `impacto` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `riesgos`
--

INSERT INTO `riesgos` (`id`, `amenaza_id`, `probabilidad`, `impacto`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 2, NULL, NULL),
(2, 2, 1, 3, NULL, NULL),
(3, 3, 1, 2, NULL, NULL),
(4, 4, 1, 3, NULL, NULL),
(5, 5, 2, 2, NULL, NULL),
(6, 6, 1, 3, NULL, NULL),
(7, 7, 1, 2, NULL, NULL),
(8, 8, 1, 3, NULL, NULL),
(9, 9, 1, 3, NULL, NULL),
(10, 10, 3, 3, NULL, NULL),
(11, 11, 1, 3, NULL, NULL),
(12, 12, 2, 2, NULL, NULL),
(13, 13, 1, 3, NULL, NULL),
(14, 14, 1, 3, NULL, NULL),
(15, 15, 1, 3, NULL, NULL),
(16, 16, 2, 2, NULL, NULL),
(17, 17, 1, 2, NULL, NULL),
(18, 18, 1, 2, NULL, NULL),
(19, 19, 1, 3, NULL, NULL),
(20, 20, 3, 2, NULL, NULL),
(21, 21, 1, 3, NULL, NULL),
(22, 22, 3, 1, NULL, NULL),
(23, 23, 1, 1, NULL, NULL),
(24, 24, 3, 1, NULL, NULL),
(25, 25, 1, 3, NULL, NULL),
(26, 26, 1, 2, NULL, NULL),
(27, 27, 1, 1, NULL, NULL),
(28, 28, 1, 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salvavulneras`
--

CREATE TABLE `salvavulneras` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amenaza_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `salvavulneras`
--

INSERT INTO `salvavulneras` (`id`, `tipo`, `descripcion`, `amenaza_id`, `created_at`, `updated_at`) VALUES
(1, 'V', 'Antivirus no actualizado', 10, NULL, NULL),
(2, 'V', 'El usuario de trabajo es el Administrador', 4, NULL, NULL),
(3, 'V', 'El usuario de trabajo es el Administrador', 16, NULL, NULL),
(4, 'V', 'Sin contraseña, pin o patrón de acceso', 21, NULL, NULL),
(5, 'V', 'No tiene extintores', 25, NULL, NULL),
(6, 'V', 'Cerradura normal no segura', 26, NULL, NULL),
(7, 'V', 'Alto consumo de consumibles', 24, NULL, NULL),
(8, 'V', 'Los inyectores de tinta se pueden secar u obstruir', 23, NULL, NULL),
(9, 'V', 'Clave por defecto delrouter Movistar', 28, NULL, NULL),
(10, 'S', 'Firewall de Windows activo con políticas concretas', 4, NULL, NULL),
(11, 'S', 'Firewall de Windows activo', 16, NULL, NULL),
(12, 'S', 'Sistema de localización de Google activado', 20, NULL, NULL),
(13, 'S', 'Sincronizado con la nube', 20, NULL, NULL),
(14, 'S', 'Control de acceso en el edificio con cámara de seguridad comunitaria', 26, NULL, NULL),
(15, 'S', 'Consumibles dereserva', 24, NULL, NULL),
(16, 'S', 'Firewall interno', 28, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `api_token` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `api_token`) VALUES
(1, 'Usuario de prueba', 'prueba@ciberpyme.com', NULL, '$2y$10$.5gHT2szSArO/NthXeEvcOzKUAH/sReHTZyA/Yax6wjkWHjtoPEyy', NULL, NULL, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `activos`
--
ALTER TABLE `activos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `activos_identificador_user_id_unique` (`identificador`,`user_id`),
  ADD KEY `activos_user_id_foreign` (`user_id`);

--
-- Indices de la tabla `amenazas`
--
ALTER TABLE `amenazas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `amenazas_id_amenaza_activo_id_unique` (`id_amenaza`,`activo_id`),
  ADD KEY `amenazas_activo_id_foreign` (`activo_id`);

--
-- Indices de la tabla `decisions`
--
ALTER TABLE `decisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `decisions_riesgo_id_foreign` (`riesgo_id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `riesgos`
--
ALTER TABLE `riesgos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `riesgos_amenaza_id_foreign` (`amenaza_id`);

--
-- Indices de la tabla `salvavulneras`
--
ALTER TABLE `salvavulneras`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `salvavulneras_amenaza_id_tipo_descripcion_unique` (`amenaza_id`,`tipo`,`descripcion`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_api_token_unique` (`api_token`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `activos`
--
ALTER TABLE `activos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `amenazas`
--
ALTER TABLE `amenazas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `decisions`
--
ALTER TABLE `decisions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `riesgos`
--
ALTER TABLE `riesgos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `salvavulneras`
--
ALTER TABLE `salvavulneras`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `activos`
--
ALTER TABLE `activos`
  ADD CONSTRAINT `activos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `amenazas`
--
ALTER TABLE `amenazas`
  ADD CONSTRAINT `amenazas_activo_id_foreign` FOREIGN KEY (`activo_id`) REFERENCES `activos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `decisions`
--
ALTER TABLE `decisions`
  ADD CONSTRAINT `decisions_riesgo_id_foreign` FOREIGN KEY (`riesgo_id`) REFERENCES `riesgos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `riesgos`
--
ALTER TABLE `riesgos`
  ADD CONSTRAINT `riesgos_amenaza_id_foreign` FOREIGN KEY (`amenaza_id`) REFERENCES `amenazas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `salvavulneras`
--
ALTER TABLE `salvavulneras`
  ADD CONSTRAINT `salvavulneras_amenaza_id_foreign` FOREIGN KEY (`amenaza_id`) REFERENCES `amenazas` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
